cusp~ : Cusp Catastrophe External for Max/MSP
=============================================

Author: Leon Steidle
Version: 2025

---------------------------------------------

DESCRIPTION
-----------
cusp~ is a Max/MSP external that calculates the real roots of the cubic equation associated with René Thom's cusp catastrophe potential. It outputs:

1. Lower stable root (z0)
2. Unstable root (z1)
3. Upper stable root (z2)
4. Current branch/state (0 = lower, 1 = upper)
5. Discriminant (D) of the cubic – indicates whether the system is inside (D < 0) or outside (D > 0) the bifurcation set.

INPUTS (audio signals, left → right)
-------------------------------------
1. alpha  – controls the constant term of the cubic
2. beta   – controls the quadratic term (scaled by width)
3. width  – global scaling of beta (kept for backward compatibility)

OUTPUTS (audio signals, left → right)
-------------------------------------
1. z0     – lower stable root
2. z1     – unstable root
3. z2     – upper stable root
4. state  – branch: 0 = lower, 1 = upper
5. D      – discriminant of the cubic

---------------------------------------------

REQUIREMENTS
------------
- Max/MSP SDK (download from https://cycling74.com/sdk)
  - Make sure the max-sdk-base submodules are present and the Makefile's MAXSDK path points to your SDK location.
- C compiler:
  - macOS: clang (default on macOS)
- GSL (GNU Scientific Library): NOT REQUIRED for this object. All cubic root calculations are handled internally.

---------------------------------------------

BUILD INSTRUCTIONS
------------------
1. Place cusp~.c and the Makefile in the same folder.
2. Edit the MAXSDK path in the Makefile if necessary to point to your Max SDK base.
3. Open a terminal in this folder and type:

   make

4. This will produce a universal binary bundle named cusp~.mxo.
5. Copy cusp~.mxo to your Max/MSP externals folder or any folder in Max's search path.

---------------------------------------------

USAGE IN MAX/MSP
----------------
- In Max/MSP, create an object box and type: cusp~
- Connect three audio signals to its inlets (alpha, beta, width)
- The object outputs the roots and discriminant as described above

---------------------------------------------

TROUBLESHOOTING
---------------
- "max-sdk-base" not found: Edit the MAXSDK variable in the Makefile to your Max SDK location.
- Build errors about missing headers: Ensure the SDK paths are set correctly and you are using clang on macOS.
- GSL errors: This object does NOT require GSL. If you see GSL errors, make sure you are not including unnecessary libraries.

---------------------------------------------

CREDITS
-------
Author: Leon Steidle
Inspired by catastrophe theory and Max/MSP external design.

License: © 2025 Leon Steidle. All rights reserved.