/*
    cusp~ : Cusp Catastrophe external for Max/MSP
    ---------------------------------------------
    Calculates the real roots of the cubic equation that derives from René Thom's cusp
    potential and outputs:
        1. Lower stable root (z0)
        2. Unstable root (z1)
        3. Upper stable root (z2)
        4. Current branch/state (0 = lower, 1 = upper)
        5. Discriminant (D) of the cubic – indicates whether the system is inside (D < 0)
           or outside (D > 0) the bifurcation set.

    Inlets  (audio signals, left → right):
        1. alpha  – controls the constant term of the cubic
        2. beta   – controls the quadratic term (scaled by width)
        3. width  – global scaling of beta (kept for backward-compatibility)

    © 2025 Leon Steidle. All rights reserved.
*/

#include "ext.h"
#include "ext_obex.h"
#include "z_dsp.h"
#include <math.h>

/* ===== Cubic solver (returns the number of real roots; roots are written to x0-x2) ===== */
static int solve_cubic(double a, double b, double c, double d, double *x0, double *x1, double *x2)
{
    /* Guard against degenerate coefficients (not a cubic) */
    if (fabs(a) < 1e-12)
        return 0;

    /* Depressed-cubic substitution: x = y – A/3 */
    double A = b / a;
    double B = c / a;
    double C = d / a;

    double Q = (3.0 * B - A * A) / 9.0;
    double R = (9.0 * A * B - 27.0 * C - 2.0 * A * A * A) / 54.0;
    double D = Q * Q * Q + R * R; /* Discriminant */

    if (D >= 0.0) { /* One real root */
        double sqrt_D = sqrt(D);
        double S = cbrt(R + sqrt_D);
        double T = cbrt(R - sqrt_D);
        *x0 = -A / 3.0 + (S + T);
        *x1 = *x2 = *x0; /* fill for safety */
        return 1;
    }
    else {           /* Three distinct real roots */
        double theta = acos(R / sqrt(-Q * Q * Q));
        double sqrt_Q = sqrt(-Q);
        *x0 = 2.0 * sqrt_Q * cos(theta / 3.0) - A / 3.0;
        *x1 = 2.0 * sqrt_Q * cos((theta + 2.0 * M_PI) / 3.0) - A / 3.0;
        *x2 = 2.0 * sqrt_Q * cos((theta + 4.0 * M_PI) / 3.0) - A / 3.0;
        return 3;
    }
}

/* ===== Utility: sort three doubles ascending ===== */
static void sort3(double *a, double *b, double *c)
{
    double t;
    if (*a > *b) { t = *a; *a = *b; *b = t; }
    if (*b > *c) { t = *b; *b = *c; *c = t; }
    if (*a > *b) { t = *a; *a = *b; *b = t; }
}

/* ===== Main object structure ===== */
typedef struct _cusp {
    t_pxobject ob;
    double alpha;
    double beta;
    double width;
    double z0, z1, z2; /* ordered roots */
    double state_var;  /* 0 = lower branch, 1 = upper branch */
} t_cusp;

static t_class *cusp_class = NULL;

/* ===== Forward declarations ===== */
void *cusp_new(t_symbol *s, long argc, t_atom *argv);
void cusp_free(t_cusp *x);
void cusp_assist(t_cusp *x, void *b, long m, long a, char *s);
void cusp_dsp64(t_cusp *x, t_object *dsp64, short *count, double samplerate, long maxvectorsize, long flags);
void cusp_perform64(t_cusp *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam);

/* ===== Boilerplate loader ===== */
void ext_main(void *r)
{
    t_class *c = class_new("cusp~", (method)cusp_new, (method)cusp_free, (long)sizeof(t_cusp), 0L, A_GIMME, 0);

    class_addmethod(c, (method)cusp_dsp64, "dsp64", A_CANT, 0);
    class_addmethod(c, (method)cusp_assist, "assist", A_CANT, 0);

    class_dspinit(c);
    class_register(CLASS_BOX, c);
    cusp_class = c;
}

/* ===== Object creation ===== */
void *cusp_new(t_symbol *s, long argc, t_atom *argv)
{
    t_cusp *x = (t_cusp *)object_alloc(cusp_class);
    if (x) {
        dsp_setup((t_pxobject *)x, 3); /* alpha, beta, width */

        /* 5 audio outlets */
        outlet_new((t_object *)x, "signal"); /* 0: lower stable */
        outlet_new((t_object *)x, "signal"); /* 1: unstable */
        outlet_new((t_object *)x, "signal"); /* 2: upper stable */
        outlet_new((t_object *)x, "signal"); /* 3: state/branch */
        outlet_new((t_object *)x, "signal"); /* 4: discriminant */

        x->alpha = 0.0;
        x->beta  = 0.0;
        x->width = 1.0;
        x->z0 = x->z1 = x->z2 = 0.0;
        x->state_var = 0.0;
    }
    return x;
}

/* ===== Object destruction ===== */
void cusp_free(t_cusp *x)
{
    dsp_free((t_pxobject *)x);
}

/* ===== Inlet/Outlet help ===== */
void cusp_assist(t_cusp *x, void *b, long m, long a, char *s)
{
    if (m == ASSIST_INLET) {
        switch (a) {
            case 0: snprintf(s, 256, "(signal) alpha"); break;
            case 1: snprintf(s, 256, "(signal) beta"); break;
            case 2: snprintf(s, 256, "(signal) width"); break;
        }
    } else {
        switch (a) {
            case 0: snprintf(s, 256, "(signal) z0 – lower stable root"); break;
            case 1: snprintf(s, 256, "(signal) z1 – unstable root"); break;
            case 2: snprintf(s, 256, "(signal) z2 – upper stable root"); break;
            case 3: snprintf(s, 256, "(signal) branch state: 0 = lower, 1 = upper"); break;
            case 4: snprintf(s, 256, "(signal) discriminant D"); break;
        }
    }
}

/* ===== DSP registration ===== */
void cusp_dsp64(t_cusp *x, t_object *dsp64, short *count, double samplerate, long maxvectorsize, long flags)
{
    object_method(dsp64, gensym("dsp_add64"), x, cusp_perform64, 0, NULL);
}

/* ===== Perform routine ===== */
void cusp_perform64(t_cusp *x, t_object *dsp64,
                    double **ins, long numins, double **outs, long numouts,
                    long sampleframes, long flags, void *userparam)
{
    double *in_alpha = ins[0];
    double *in_beta  = ins[1];
    double *in_width = ins[2];

    double *out_z0   = outs[0];
    double *out_z1   = outs[1];
    double *out_z2   = outs[2];
    double *out_state= outs[3];
    double *out_disc = outs[4];

    for (int i = 0; i < sampleframes; ++i) {
        /* Read control signals */
        x->alpha = in_alpha[i];
        x->beta  = in_beta[i];
        x->width = in_width[i];

        /* Coefficients of cubic: z^3 + (beta*width) * z + alpha = 0 */
        double a = 1.0; /* z^3 term */
        double b = 0.0; /* z^2 term (absent) */
        double c = x->beta * x->width; /* z term */
        double d = x->alpha;           /* constant term */

        /* Solve cubic – writes roots into z0-z2 */
        int nroots = solve_cubic(a, b, c, d, &x->z0, &x->z1, &x->z2);

        /* Sort the three roots so that z0 ≤ z1 ≤ z2 */
        if (nroots == 3)
            sort3(&x->z0, &x->z1, &x->z2);

        /* Compute discriminant again (cheaper than extending solver API) */
        double A = b / a; /* zero */
        double B = c / a;
        double C = d / a;
        double Q = (3.0 * B - A * A) / 9.0;
        double R = (9.0 * A * B - 27.0 * C - 2.0 * A * A * A) / 54.0;
        double D = Q * Q * Q + R * R; /* discriminant */

        /* Branch selection logic */
        if (nroots == 1) {
            /* Outside cusp: only one real root (store in z0) */
            out_z0[i] = x->z0;
            out_z1[i] = 0.0;
            out_z2[i] = 0.0;
            x->state_var = (x->z0 > 0.0) ? 1.0 : 0.0;
            out_state[i] = x->state_var;
        }
        else {
            /* Inside cusp: three real roots */
            out_z0[i] = x->z0; /* lower stable */
            out_z1[i] = x->z1; /* unstable */
            out_z2[i] = x->z2; /* upper stable */
            out_state[i] = x->state_var; /* state_var can be driven externally */
        }

        /* Output discriminant */
        out_disc[i] = D;
    }
}